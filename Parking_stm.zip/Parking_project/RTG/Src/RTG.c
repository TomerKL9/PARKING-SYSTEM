#include "RTG.h"

#define TOTAL_DATA_SIZE 4				//Change to match your UART number
#define TOTAL_DATA_OUT_SIZE 1				//Change to match your UART number
#define BUFFERSIZE 50

uint8_t uart_flag_calback = 0;				//Flag indicating UART completion
uint8_t randomChar;						//random car slot number.
uint8_t buff[BUFFERSIZE];						//Buffer to store UART data.
HAL_StatusTypeDef status; 				//Status of HAL functions.
volatile int SIMULATIONON = 1; //simulation on flag
uint8_t generateRandomChar();

/**
 * @brief Main function for RTG operation.
 *
 * Initializes the system, handles UART communication, and responds with parking slot information.
 */
void rtg_main()
{
	printf("\r\n START\r\n");
	status = HAL_UART_Receive_IT(UART_4, buff, TOTAL_DATA_SIZE);	//Prepare UART to receive 10 bytes of data to buff
	if(status != HAL_OK)
	{
		printf("UART_Receive failed with status: %d", status);
		SIMULATIONON = 0;
	}
    while (SIMULATIONON) {
    	if (uart_flag_calback)  { // When USER GPIO triggers
			randomChar = generateRandomChar();
			printf("city: %u\n\r", randomChar);
			// Send carCommand and carPlace via UART

			status = HAL_UART_Transmit(UART_4, &randomChar, TOTAL_DATA_OUT_SIZE, 100); //Prepare UART to receive 10 bytes of data to buff
			if (status != HAL_OK) {
				printf("UART_5 send failed with status: %d", status);
				SIMULATIONON = 0;
			}
			status = HAL_UART_Receive_IT(UART_4, buff, TOTAL_DATA_SIZE);				//Prepare UART to receive 10 bytes of data to buff
			if(status != HAL_OK)
			{
				printf("UART_Receive failed with status: %d", status);
				SIMULATIONON = 0;
			}
            uart_flag_calback=0;
        }

    }
	return;
}


/**
 * @brief Callback function invoked when UART data reception is complete.
 *
 * Sets the uart_flag_calback to indicate that UART reception is complete.
 *
 * @param huart Pointer to UART handler.
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
		uart_flag_calback = 1;
}

/**
 * @brief Generates a random character (parking slot number).
 * @return Randomly generated character.
 */
uint8_t generateRandomChar() {
    return (uint8_t)(rand() % 255 + 1); // Generates a random parking number
}

