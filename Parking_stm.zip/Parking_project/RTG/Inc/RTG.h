/*
 * RTG.h
 *
 *  Created on: Oct 2, 2022
 *      Author: RTG
 *
 */
#ifndef INC_RTG_H_
#define INC_RTG_H_
#include "main.h"
#include "stm32f7xx_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>  // For standard integer types like uint8_t
#include <time.h>    // For time-related functions (if you want to seed the random number generator)


extern UART_HandleTypeDef huart4;	//Change to match your UART number
extern UART_HandleTypeDef huart3;	//Change to match your UART number
extern uint8_t uart_flag_calback;
extern uint8_t uart_flag_h;

#define UART_DEBUG &huart3				//Debug UART
#define UART_4 &huart4				//Debug UART
#define GPIO_PER_1 GPIOB				//Change to match your peripheral section (for led 1)
#define GPIO_PER_2 GPIOB				//Change to match your peripheral section (for led 2)
#define GPIO_PER_3 GPIOB				//Change to match your peripheral section (for led 3)
#define GPIO_PER_4 GPIOC				//User button peripheral section
#define GPIO_LED_1 LD1_Pin				//Sets the first led's pin number
#define GPIO_LED_2 LD2_Pin				//Sets the second led's pin number
#define GPIO_USER_BUTTON GPIO_PIN_13	//User button's pin number

void rtg_main();
#endif /* INC_RTG_H_ */
